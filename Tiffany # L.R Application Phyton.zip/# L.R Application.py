import tkinter as tk
from tkinter import messagebox

# Global variables to store user data
users_db = {}

# Function for Register screen
def open_register_screen():
    login_frame.pack_forget()  # Hide login frame
    register_frame.pack(pady=20)

def register_user():
    username = username_entry.get()
    password = password_entry.get()
    
    if username in users_db:
        messagebox.showerror("Error", "User already exists!")
    elif not username or not password:
        messagebox.showerror("Error", "Please fill in both fields!")
    else:
        users_db[username] = password
        messagebox.showinfo("Success", "Registration successful!")
        register_frame.pack_forget()  # Hide register frame
        login_frame.pack(pady=20)  # Show login frame again

# Function for Login screen
def open_login_screen():
    register_frame.pack_forget()  # Hide register frame
    login_frame.pack(pady=20)

def login_user():
    username = username_login_entry.get()
    password = password_login_entry.get()

    if username in users_db and users_db[username] == password:
        messagebox.showinfo("Success", "Login successful!")
        login_frame.pack_forget()  # Hide login frame
        home_screen()
    else:
        messagebox.showerror("Error", "Invalid username or password!")

# Function for Home screen
def home_screen():
    home_frame.pack(pady=20)
    
    welcome_label = tk.Label(home_frame, text="Welcome to the Home Screen", font=("Arial", 14))
    welcome_label.pack(pady=10)

    go_to_screen2_button = tk.Button(home_frame, text="Go to Screen 2", command=go_to_screen2)
    go_to_screen2_button.pack(pady=10)

    go_to_screen3_button = tk.Button(home_frame, text="Go to Screen 3", command=go_to_screen3)
    go_to_screen3_button.pack(pady=10)

# Function for Screen 2
def go_to_screen2():
    home_frame.pack_forget()  # Hide home screen
    screen2_frame.pack(pady=20)

def back_to_home_from_screen2():
    screen2_frame.pack_forget()  # Hide screen 2
    home_screen()

# Function for Screen 3
def go_to_screen3():
    home_frame.pack_forget()  # Hide home screen
    screen3_frame.pack(pady=20)

def back_to_home_from_screen3():
    screen3_frame.pack_forget()  # Hide screen 3
    home_screen()

# Set up the main window
app = tk.Tk()
app.title("Simple Login & Register App")
app.geometry("400x400")

# Create frames for each screen
login_frame = tk.Frame(app)
register_frame = tk.Frame(app)
home_frame = tk.Frame(app)
screen2_frame = tk.Frame(app)
screen3_frame = tk.Frame(app)

# ----------------------------- Login Screen ------------------------------
# Login screen UI
tk.Label(login_frame, text="Login", font=("Arial", 18)).pack(pady=20)

tk.Label(login_frame, text="Username:").pack(pady=5)
username_login_entry = tk.Entry(login_frame)
username_login_entry.pack(pady=5)

tk.Label(login_frame, text="Password:").pack(pady=5)
password_login_entry = tk.Entry(login_frame, show="*")
password_login_entry.pack(pady=5)

login_button = tk.Button(login_frame, text="Login", command=login_user)
login_button.pack(pady=10)

register_button = tk.Button(login_frame, text="Don't have an account? Register", command=open_register_screen)
register_button.pack(pady=5)

# ----------------------------- Register Screen ------------------------------
# Register screen UI
tk.Label(register_frame, text="Register", font=("Arial", 18)).pack(pady=20)

tk.Label(register_frame, text="Username:").pack(pady=5)
username_entry = tk.Entry(register_frame)
username_entry.pack(pady=5)

tk.Label(register_frame, text="Password:").pack(pady=5)
password_entry = tk.Entry(register_frame, show="*")
password_entry.pack(pady=5)

register_button = tk.Button(register_frame, text="Register", command=register_user)
register_button.pack(pady=10)

back_to_login_button = tk.Button(register_frame, text="Back to Login", command=open_login_screen)
back_to_login_button.pack(pady=5)

# ----------------------------- Home Screen ------------------------------
# Home screen UI
home_label = tk.Label(home_frame, text="Home Screen", font=("Arial", 18))
home_label.pack(pady=20)

# ----------------------------- Screen 2 ------------------------------
screen2_label = tk.Label(screen2_frame, text="This is Screen 2", font=("Arial", 14))
screen2_label.pack(pady=20)

back_button_screen2 = tk.Button(screen2_frame, text="Back to Home", command=back_to_home_from_screen2)
back_button_screen2.pack(pady=10)

# ----------------------------- Screen 3 ------------------------------
screen3_label = tk.Label(screen3_frame, text="This is Screen 3", font=("Arial", 14))
screen3_label.pack(pady=20)

back_button_screen3 = tk.Button(screen3_frame, text="Back to Home", command=back_to_home_from_screen3)
back_button_screen3.pack(pady=10)

# ----------------------------- Start with the Login Screen ------------------------------
login_frame.pack(pady=20)

app.mainloop()
